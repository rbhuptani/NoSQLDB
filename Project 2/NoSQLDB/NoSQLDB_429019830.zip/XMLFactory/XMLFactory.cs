﻿///////////////////////////////////////////////////////////////
// XMLFactory.cs - define methods to simplify XML operations //
// Ver 1.1                                                   //
// Application: Demonstration for CSE681-SMA, Project#2      //
// Language:    C#, ver 6.0, Visual Studio 2015              //
// Platform:    MSI GE62, Core-i7, Windows 10                //
// Author:      Ronak Bhuptani, SUID#429019830, Syracuse     //
//              University, rmbhupta@syr.edu                 //
///////////////////////////////////////////////////////////////
/*
 * Package Operations:
 * -------------------
 * This package implements XMLFactory. It will help PersistEngine
 * to persist database into xml file.
 *
 */
/*
 * Maintenance:
 * ------------
 * Required Files: 
 *
 * Build Process:  devenv Project2Starter.sln /Rebuild debug
 *                 Run from Developer Command Prompt
 *                 To find: search for developer
 *
 * Maintenance History:
 * --------------------
 * ver 1.0 : 30 Sep 15
 * - first release
 *
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using static System.Console;
namespace Project2Starter
{
    public class XMLFactory
    {
        // create function will create new xml file and set comments.
        public static int create(string fileName,string comments = "type of this file was not mentioned in crreate function.")
        {
            fileName = correct_path(fileName);
            if (!File.Exists(fileName))
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;
                XmlWriter writer = XmlWriter.Create(@fileName, settings);
                if (writer != null)
                {
                    writer.WriteStartDocument();
                    writer.WriteComment(comments);
                    writer.WriteStartElement("nosqldb");
                    writer.WriteEndElement();
                    writer.WriteEndDocumentAsync();
                    writer.Flush();
                    writer.Close();
                    return 1; //new file created
                }
                else
                    return -1;  // -1 is for file does not exist and is not created.
            }
            else
                return 0; // file exists.  
        }
        //this function will reform the filepath
        public static string correct_path(string fileName)
        {
            string temp = AppDomain.CurrentDomain.BaseDirectory;
            int j = 0;
            while (j != 4)
            {
                int i = temp.LastIndexOf("\\");
                temp = temp.Substring(0, i);
                j++;
            }
            //temp = temp + "\\";
            if (fileName.EndsWith(".xml"))
                fileName = temp + "\\" + fileName;
            else
                fileName = temp + "\\" + fileName + ".xml";
            return fileName;
        }
        //this function will convert the xml file into string
        public bool xmlTostring(string fileName, out string reader)
        {   
            string temp = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;
            if (fileName.EndsWith(".xml"))
                fileName = temp + "/" + fileName;
            else
                fileName = temp + "/" + fileName + ".xml";
            if (File.Exists(fileName))
            {
                reader = System.IO.File.ReadAllText(fileName) + "\n";
                return true;
            }
            reader = "";
            return false;
        }

    }
    class TestXMLFactory
    {
        static void Main(string[] args)
        {
            "Testing XMLFactory".title();
            Console.WriteLine("\n Showing Package structure of current solution.\n");
            string reader;
            XMLFactory x = new XMLFactory();
            x.xmlTostring("ProjectStructure", out reader);
            Console.WriteLine(reader);
            
            Console.WriteLine(XMLFactory.correct_path("abc"));
        }
    }
}
